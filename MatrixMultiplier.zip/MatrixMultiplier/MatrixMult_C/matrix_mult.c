#include <stdlib.h>
#include "matrix_mult.h"

double** allocate_matrix(int n) {
    double** m = malloc(n * sizeof(double*));
    for (int i = 0; i < n; i++)
        m[i] = malloc(n * sizeof(double));
    return m;
}

void free_matrix(double** m, int n) {
    for (int i = 0; i < n; i++)
        free(m[i]);
    free(m);
}

void generate_matrix(double** m, int n) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            m[i][j] = (double)rand() / RAND_MAX;
}

void multiply_matrices(double** A, double** B, double** C, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            double sum = 0.0;
            for (int k = 0; k < n; k++) {
                sum += A[i][k] * B[k][j];
            }
            C[i][j] = sum;
        }
    }
}
