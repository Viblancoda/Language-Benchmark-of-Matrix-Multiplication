#ifndef MATRIX_MULT_H
#define MATRIX_MULT_H

double** allocate_matrix(int n);
void free_matrix(double** m, int n);
void generate_matrix(double** m, int n);
void multiply_matrices(double** A, double** B, double** C, int n);

#endif
