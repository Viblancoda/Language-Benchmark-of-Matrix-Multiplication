#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/resource.h>
#include "matrix_mult.h"

double timeval_to_sec(struct timeval t) {
    return t.tv_sec + t.tv_usec / 1e6;
}

void benchmark_matrix_multiplication(FILE* csv, int n, int runs) {
    double total_time = 0.0;
    double memory_MB = 3.0 * n * n * sizeof(double) / (1024.0 * 1024.0);
    double total_cpu = 0.0;

    for (int r = 0; r < runs; r++) {
        double** A = allocate_matrix(n);
        double** B = allocate_matrix(n);
        double** C = allocate_matrix(n);

        generate_matrix(A, n);
        generate_matrix(B, n);

        struct rusage usage_start, usage_end;
        getrusage(RUSAGE_SELF, &usage_start);

        clock_t start = clock();
        multiply_matrices(A, B, C, n);
        clock_t end = clock();

        getrusage(RUSAGE_SELF, &usage_end);

        double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
        total_time += elapsed;

        double cpu_time = timeval_to_sec(usage_end.ru_utime) + timeval_to_sec(usage_end.ru_stime)
                        - (timeval_to_sec(usage_start.ru_utime) + timeval_to_sec(usage_start.ru_stime));
        total_cpu += cpu_time;

        free_matrix(A, n);
        free_matrix(B, n);
        free_matrix(C, n);
    }

    double avg_time = total_time / runs;
    double avg_cpu = total_cpu / runs;

    printf("Matrix size: %dx%d\n", n, n);
    printf("Average execution time over %d runs: %.6f seconds\n", runs, avg_time);
    printf("Estimated memory usage: %.2f MB\n", memory_MB);
    printf("Average CPU time: %.6f seconds\n\n", avg_cpu);

    fprintf(csv, "%d,%.6f,%.2f,%.6f\n", n, avg_time, memory_MB, avg_cpu);
}

int main() {
    int sizes[] = {128, 256, 512};
    int runs = 3;

    FILE* csv = fopen("results.csv", "w");
    if (csv == NULL) {
        perror("Error al crear results.csv");
        return 1;
    }

    fprintf(csv, "Matrix_Size,Avg_Time(s),Memory(MB),CPU_Time(s)\n");

    for (int i = 0; i < sizeof(sizes)/sizeof(sizes[0]); i++)
        benchmark_matrix_multiplication(csv, sizes[i], runs);

    fclose(csv);
    printf("Resultados guardados en 'results.csv'\n");

    return 0;
}