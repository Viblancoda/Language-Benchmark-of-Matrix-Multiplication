package benchmark;

import matrix.MatrixMultiplier;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

public class Benchmark {

    public static void benchmarkMatrixMultiplication(int n, int runs, PrintWriter writer) {
        MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();

        double totalTime = 0.0;
        double totalMem = 0.0;

        for (int r = 0; r < runs; r++) {
            double[][] A = MatrixMultiplier.generateMatrix(n);
            double[][] B = MatrixMultiplier.generateMatrix(n);

            MemoryUsage beforeMem = memoryBean.getHeapMemoryUsage();
            long beforeUsedMem = beforeMem.getUsed();

            long startTime = System.nanoTime();
            MatrixMultiplier.multiplyMatrices(A, B);
            long endTime = System.nanoTime();

            MemoryUsage afterMem = memoryBean.getHeapMemoryUsage();
            long afterUsedMem = afterMem.getUsed();

            double elapsedSeconds = (endTime - startTime) / 1_000_000_000.0;
            double usedMemMB = (afterUsedMem - beforeUsedMem) / (1024.0 * 1024.0);

            totalTime += elapsedSeconds;
            totalMem += Math.max(0, usedMemMB);
        }

        double avgTime = totalTime / runs;
        double avgMem = totalMem / runs;

        System.out.printf("%nMatrix size: %dx%d%n", n, n);
        System.out.printf("Average execution time: %.4f seconds%n", avgTime);
        System.out.printf("Average additional memory usage: %.2f MB%n", avgMem);

        writer.printf(Locale.US, "%d,%.6f,%.4f%n", n, avgTime, avgMem);
    }

    public static void main(String[] args) {
        int[] sizes = {128, 256, 512};
        int runs = 3;

        try (PrintWriter writer = new PrintWriter(new FileWriter("results_java.csv"))) {
            writer.println("Matrix_Size,Avg_Time(s),Avg_Memory(MB)");
            for (int n : sizes) {
                benchmarkMatrixMultiplication(n, runs, writer);
            }
            System.out.println("\nResultados guardados en results_java.csv con formato decimal correcto ('.').");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
