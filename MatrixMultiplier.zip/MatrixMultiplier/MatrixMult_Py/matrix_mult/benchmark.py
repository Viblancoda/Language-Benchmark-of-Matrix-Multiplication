import time
import tracemalloc
import psutil
import csv
from matrix_mult import generate_matrix, multiply_matrices


def benchmark_matrix_multiplication(n, runs=3):
    process = psutil.Process()
    times = []
    mem_usages = []

    for r in range(runs):
        A = generate_matrix(n)
        B = generate_matrix(n)

        tracemalloc.start()
        start_time = time.perf_counter()

        multiply_matrices(A, B)

        end_time = time.perf_counter()
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        times.append(end_time - start_time)
        mem_usages.append(peak / (1024 ** 2))

    avg_time = sum(times) / len(times)
    avg_mem = sum(mem_usages) / len(mem_usages)

    print(f"\nMatrix size: {n}x{n}")
    print(f"Average execution time: {avg_time:.4f} seconds")
    print(f"Average peak memory usage: {avg_mem:.2f} MB")

    return n, avg_time, avg_mem


if __name__ == "__main__":
    results = []
    sizes = [128, 256, 512]
    runs = 3

    for n in sizes:
        results.append(benchmark_matrix_multiplication(n, runs=runs))

    with open("results_python.csv", mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["Matrix_Size", "Avg_Time(s)", "Avg_Memory(MB)"])
        writer.writerows(results)

    print("\nResultados guardados en 'results_python.csv'")
